import React, { useState } from 'react';
import { parse } from '@webtoon/psd';

function App() {
  const [layers, setLayers] = useState([]);

  async function handleUpload(e) {
    const file = e.target.files[0];
    const buffer = await file.arrayBuffer();
    const psd = parse(buffer);
    const texts = psd.children.filter(l => l.text?.text);
    setLayers(texts.map(l => ({ id: l.layerId, text: l.text.text })));
  }

  return (
    <div style={{ padding: 20 }}>
      <h2>محرر نصوص PSD</h2>
      <input type="file" accept=".psd" onChange={handleUpload} />
      {layers.map((l, i) => (
        <div key={i} style={{ marginTop: 10 }}>
          <input value={l.text} style={{ width: 300 }} readOnly />
        </div>
      ))}
    </div>
  );
}

export default App;